<?php
if (isset($_POST['del'])) {
echo $_POST['del_id'];
}